console.log("This is Vaishnavi Kanade's Docker File")
console.log("Welcome Everyone")
console.log("Assignment 2")
console.log("Part B")