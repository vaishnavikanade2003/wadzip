const express = require('express');
const app = express();

// Serve files from the public directory
app.use(express.static('public'));

app.listen(2003,()=>{
  console.log("Server is started");
})
